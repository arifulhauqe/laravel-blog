<!DOCTYPE html>
<html lang="en">
  @include('partials._head')
  <body>
    @include('partials._nav')

    @yield('slider')

    <!-- Page Content -->
    <div class="container">
      @include('partials._messages')
      
  
      @yield('content')
    </div>
    <!-- /.container -->
    @include('partials._footer')
    @include('partials._script')
  </body>
</html>
