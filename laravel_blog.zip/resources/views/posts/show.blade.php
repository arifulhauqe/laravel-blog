@extends('main')
@section('title', ' | View Post')
@section('content')

<h1 class="mt-4 mb-3">View Post</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Home</a>
      </li>
      <li class="breadcrumb-item active">View</li>
    </ol>
<div class="row">
	<div class="col-md-8">
		<h1>{{$post->title}}</h1>
		<p class="lead">{{$post->body}}</p>	
	</div>
	<div class="col-md-4 alert alert-secondary" role="alert">
		<div class="well">
			<dl class="dl-horizontal">
				<dt>Url Slug::</dt>
				<!-- <dd><a href="{{ url('blog/'.$post->slug) }}">{{ url($post->slug) }}</a></dd> -->
				<dd><a href="{{ route('blog.single', $post->slug) }}">{{ route('blog.single', $post->slug) }}</a></dd>
			</dl>
			<dl class="dl-horizontal">
				<dt>Created At:</dt>
				<dd>{{ date('M j, Y h:ia', strtotime($post->created_at)) }}</dd>
			</dl>
			<dl class="dl-horizontal">
				<dt>Last Updated:</dt>
				<dd>{{ date('M j, Y h:ia', strtotime($post->updated_at)) }}</dd>
			</dl>
			<hr>
			<div class="row">
				<div class="col-sm-6">
					<a href="{{ route('posts.edit', [$post->id], false) }}" class="btn btn-primary btn-block">Edit</a>
				</div>
				<div class="col-sm-6">
					{!! Form::open(['route' => ['posts.destroy', $post->id], 'method' => 'DELETE']) !!}
						{{Form::submit('Delete', ['class' => 'btn btn-danger btn-block'])}}
					{!! Form::close() !!}
				</div>
			</div>
			
		</div>
	</div>
</div>
@endsection