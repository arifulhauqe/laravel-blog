@extends('main')

  @section('title', '| Create New Post')
  @section('content')

  	<h1 class="mt-4 mb-3">Contact
      <small>Subheading</small>
    </h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.html">Home</a>
      </li>
      <li class="breadcrumb-item active">Contact</li>
    </ol>
	<div class="row">
      <div class="col-lg-8 mb-4">
        <h3>Create New Post</h3>
        <form name="sentMessage" id="postForm" action="/posts" method="post">
        	@csrf
        	@method('POST')
          <div class="control-group form-group">
            <div class="controls">
              <label>Title:</label>
              <input type="text" name="title" class="form-control" id="title">
              <p class="help-block"></p>
            </div>
          </div>

          <div class="control-group form-group">
            <div class="controls">
              <label>Slug:</label>
              <input type="text" name="slug" class="form-control" id="slug">
              <p class="help-block"></p>
            </div>
          </div>
          
          <div class="control-group form-group">
            <div class="controls">
              <label>Body:</label>
              <textarea rows="10" name="body" cols="100" class="form-control" id="message" maxlength="999" style="resize:none"></textarea>
            </div>
          </div>
          <div id="success"></div>
          <!-- For success/fail messages -->
          <button type="submit" class="btn btn-primary" id="sendMessageButton">Create Post</button>
        </form>
      </div>

    </div>

  @endsection