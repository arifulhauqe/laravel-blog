@extends('main')
@section('title', '| All Posts')

@section('content')
<h1 class="mt-4 mb-3">All Posts</h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.html">Home</a>
      </li>
      <li class="breadcrumb-item active">Blog Home 2</li>
    </ol>

    <div class="row">
      <div class="col-md-3">
      	<a href="{{ route('posts.create') }}" class="btn btn-success btn-block">Create New Post</a>
      </div>
    </div>  

    <hr>
    <div class="row">
    	<div class="col-md-12">
    		<table class="table table-striped">
			  <thead>
			    <tr>
			      <th scope="col">#</th>
			      <th scope="col">Title</th>
			      <th scope="col">Body</th>
			      <th scope="col">Body</th>
			      <th scope="col">Created At</th>
			      <th scope="col">Action</th>
			    </tr>
			  </thead>
			  <tbody>
			  	@foreach ($posts as $post)
			  		<tr>
				      <th scope="row">{{$post->id}}</th>
				      <td>{{$post->title}}</td>
				      <td>{{$post->body}}{{strlen($post->body) > 20 ? "...":""}}</td>
				      <td>{{$post->title}}</td>
				      <td>{{ date('M j, Y h:ia', strtotime($post->created_at)) }}</td>
				      <td scope="col"><a href="{{ route('posts.show', [$post->id], false) }}" class="btn btn-primary">View</a>  <a href="{{ route('posts.destroy', [$post->id], false) }}" class="btn btn-danger">delete</a></td>
				    </tr>
			  	@endforeach
			  </tbody>
			</table>
			<div class="text-center">
			  	{!! $posts-> links(); !!}
			  </div>
    	</div>
    </div>
   
@endsection