 <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="{{('/')}}">Arif</a>
     
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item {{Request::is('/') ? 'active':''}}">
            <a class="nav-link" href="{{('/')}}">Home</a>
          </li>
           <li class="nav-item {{Request::is('blog') ? 'active':''}}">
            <a class="nav-link" href="{{('/blog')}}">Blog</a>
          </li>
          <li class="nav-item {{Request::is('contact') ? 'active':''}}">
            <a class="nav-link" href="{{('/contact')}}">Contact</a>
          </li>
        </ul>
      </div>

      @if(Auth::check())
      <div class="btn-group">
        <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Hello {{Auth::user()->name}}
        </button>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="{{route('posts.index')}}">Posts</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="{{route('logout')}}">Logout</a>
        </div>
      </div>
      @else
      <a href="{{route('login')}}" class="btn btn-primary">Login</a>
      @endif
    </div>
  </nav>