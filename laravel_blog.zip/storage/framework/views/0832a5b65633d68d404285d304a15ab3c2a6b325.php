
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Blog <?php echo $__env->yieldContent('title'); ?></title>

  <!-- Bootstrap core CSS -->
  <link href="/asset/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Custom styles for this template -->
  <link href="/asset/css/modern-business.css" rel="stylesheet">

</head><?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/_head.blade.php ENDPATH**/ ?>