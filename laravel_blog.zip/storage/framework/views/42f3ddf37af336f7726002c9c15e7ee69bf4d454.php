<?php $__env->startSection('title', ' | View Post'); ?>
<?php $__env->startSection('content'); ?>

<h1 class="mt-4 mb-3">View Post</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Home</a>
      </li>
      <li class="breadcrumb-item active">View</li>
    </ol>
<div class="row">
	<div class="col-md-8">
		<h1><?php echo e($post->title); ?></h1>
		<p class="lead"><?php echo e($post->body); ?></p>	
	</div>
	<div class="col-md-4 alert alert-secondary" role="alert">
		<div class="well">
			<dl class="dl-horizontal">
				<dt>Url Slug::</dt>
				<!-- <dd><a href="<?php echo e(url('blog/'.$post->slug)); ?>"><?php echo e(url($post->slug)); ?></a></dd> -->
				<dd><a href="<?php echo e(route('blog.single', $post->slug)); ?>"><?php echo e(route('blog.single', $post->slug)); ?></a></dd>
			</dl>
			<dl class="dl-horizontal">
				<dt>Created At:</dt>
				<dd><?php echo e(date('M j, Y h:ia', strtotime($post->created_at))); ?></dd>
			</dl>
			<dl class="dl-horizontal">
				<dt>Last Updated:</dt>
				<dd><?php echo e(date('M j, Y h:ia', strtotime($post->updated_at))); ?></dd>
			</dl>
			<hr>
			<div class="row">
				<div class="col-sm-6">
					<a href="<?php echo e(route('posts.edit', [$post->id], false)); ?>" class="btn btn-primary btn-block">Edit</a>
				</div>
				<div class="col-sm-6">
					<?php echo Form::open(['route' => ['posts.destroy', $post->id], 'method' => 'DELETE']); ?>

						<?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger btn-block'])); ?>

					<?php echo Form::close(); ?>

				</div>
			</div>
			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/posts/show.blade.php ENDPATH**/ ?>