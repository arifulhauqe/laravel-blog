 <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="<?php echo e(('/')); ?>">Arif</a>
     
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item <?php echo e(Request::is('/') ? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(('/')); ?>">Home</a>
          </li>
           <li class="nav-item <?php echo e(Request::is('blog') ? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(('/blog')); ?>">Blog</a>
          </li>
          <li class="nav-item <?php echo e(Request::is('contact') ? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(('/contact')); ?>">Contact</a>
          </li>
        </ul>
      </div>

      <?php if(Auth::check()): ?>
      <div class="btn-group">
        <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Hello <?php echo e(Auth::user()->name); ?>

        </button>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(route('posts.index')); ?>">Posts</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a>
        </div>
      </div>
      <?php else: ?>
      <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login</a>
      <?php endif; ?>
    </div>
  </nav><?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/_nav.blade.php ENDPATH**/ ?>