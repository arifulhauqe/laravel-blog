  <!-- Bootstrap core JavaScript -->
  <script src="/asset/vendor/jquery/jquery.min.js"></script>
  <script src="/asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/_script.blade.php ENDPATH**/ ?>