<?php $__env->startSection('title', '| All Posts'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="mt-4 mb-3">All Posts</h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.html">Home</a>
      </li>
      <li class="breadcrumb-item active">Blog Home 2</li>
    </ol>

    <div class="row">
      <div class="col-md-3">
      	<a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success btn-block">Create New Post</a>
      </div>
    </div>  

    <hr>
    <div class="row">
    	<div class="col-md-12">
    		<table class="table table-striped">
			  <thead>
			    <tr>
			      <th scope="col">#</th>
			      <th scope="col">Title</th>
			      <th scope="col">Body</th>
			      <th scope="col">Body</th>
			      <th scope="col">Created At</th>
			      <th scope="col">Action</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<tr>
				      <th scope="row"><?php echo e($post->id); ?></th>
				      <td><?php echo e($post->title); ?></td>
				      <td><?php echo e($post->body); ?><?php echo e(strlen($post->body) > 20 ? "...":""); ?></td>
				      <td><?php echo e($post->title); ?></td>
				      <td><?php echo e(date('M j, Y h:ia', strtotime($post->created_at))); ?></td>
				      <td scope="col"><a href="<?php echo e(route('posts.show', [$post->id], false)); ?>" class="btn btn-primary">View</a>  <a href="<?php echo e(route('posts.destroy', [$post->id], false)); ?>" class="btn btn-danger">delete</a></td>
				    </tr>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </tbody>
			</table>
			<div class="text-center">
			  	<?php echo $posts-> links();; ?>

			  </div>
    	</div>
    </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/posts/index.blade.php ENDPATH**/ ?>