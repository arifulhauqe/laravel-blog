<?php $__env->startSection('title', "| $post->title"); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h1><?php echo e($post->title); ?></h1>
			<p><?php echo e($post->body); ?></p>
			<hr>
			<p>Posted In: <?php echo e($post->category->name); ?></p>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/blog/single.blade.php ENDPATH**/ ?>