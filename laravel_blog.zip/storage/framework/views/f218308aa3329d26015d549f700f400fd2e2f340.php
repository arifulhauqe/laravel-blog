  

  <?php $__env->startSection('title', '| Home'); ?>

  <!-- Page Content -->
  <?php $__env->startSection('content'); ?>

    <header class="jumbotron my-4">
      <h1 class="display-3">A Warm Welcome!</h1>
      <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa, ipsam, eligendi, in quo sunt possimus non incidunt odit vero aliquid similique quaerat nam nobis illo aspernatur vitae fugiat numquam repellat.</p>
      <a href="#" class="btn btn-primary btn-lg">Call to action!</a>
    </header>

    <div class="row">
      <div class="col-md-12">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="post">
            <h3><?php echo e($post->title); ?></h3>
            <p><?php echo e(substr($post->body, 0, 300)); ?><?php echo e(strlen($post->body) > 300 ? "..." : ""); ?></p>
            <a href="<?php echo e(url('blog/'.$post->slug)); ?>" class="btn btn-primary">Read More</a>
          </div>
          <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>

   

  <?php $__env->stopSection(); ?>
  <!-- /.container -->

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/pages/welcome.blade.php ENDPATH**/ ?>